#ifndef ISA2_h
#define ISA2_h

/*  This library supports the ISA Scale IVT Modular current/voltage sensor device.  These devices measure current, up to three voltages, and provide temperature compensation.

    This library was written by Jack Rickard of EVtv - http://www.evtv.me copyright 2016
    You are licensed to use this library for any purpose, commercial or private, 
    without restriction.
    
*/ 
#include <SPI.h>
#include <Arduino.h>
#include <DueTimer.h>
#include <due_wire.h>
#include <Wire_EEPROM.h>
#include "variant.h"
#include <due_can.h>
#define Serial SerialUSB

class EPROM {
	  public:
		double AH;
		double KWH;
		double KWHtrip;
		double KW;
		double Odometer;
		double Trip;
		uint8_t capacity;
		uint8_t SOC;
		double jackoff;
		uint16_t averageWHM;
		uint8_t varsGood;		
};				
	
class ISA : public CANListener
{
	
	
		
		

	public:
		ISA();
    ~ISA();
		void initialize();
		void begin(int Port, int speed);
		void initCurrent();
		void sendSTORE();
		void STOP();
		void START();
		void RESTART();
		void deFAULT();
		void initializeEPROM();
		
		EPROM EVars;

		float Amperes;   // Floating point with current in Amperes
		double ah;      //Floating point with accumulated ampere-hours
		double kwh;
		double kwhtrip;
		double Voltage;
		double Voltage1;
		double Voltage2;
		double Voltage3;
		double VoltageHI;
		double Voltage1HI;
		double Voltage2HI;
		double Voltage3HI;
		double VoltageLO;
		double Voltage1LO;
		double Voltage2LO;
		double Voltage3LO;

		double Temperature;
		double KW;
		double KWH;
		float oldKWH;
		float KWHtrip;
		float SOC;
				
		bool debug;
		bool debug2;
		bool firstframe;
		int framecount;
		unsigned long timestamp;
		double milliamps;
		long watt;
		long As;
		long wh;		
		CANRaw *canPort;
		uint8_t canEnPin;
		int canSpeed;
		uint8_t page;
		int READED;
		int WROTED;
		int ISGOOD;
		
	private:
      	CAN_FRAME frame;
		unsigned long elapsedtime;
		double  ampseconds;
		int milliseconds ;
		int seconds;
		int minutes;
		int hours;
		char buffer[9];
		char bigbuffer[90];
		uint32_t inbox;
		CAN_FRAME outframe;
		
		void gotFrame(CAN_FRAME *frame, int mailbox); // CAN interrupt service routine	
		void printCAN(CAN_FRAME *frame);
		void handle521(CAN_FRAME *frame);
		void handle522(CAN_FRAME *frame);
		void handle523(CAN_FRAME *frame);
		void handle524(CAN_FRAME *frame);
		void handle525(CAN_FRAME *frame);
		void handle526(CAN_FRAME *frame);
		void handle527(CAN_FRAME *frame);
		void handle528(CAN_FRAME *frame);
		
								
};

#endif /* ISA2_h */
